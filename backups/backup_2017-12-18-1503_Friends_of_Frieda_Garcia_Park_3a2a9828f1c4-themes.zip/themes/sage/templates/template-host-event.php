<?php
/**
 * Template Name: Host Event Template
 */
?>
  <?php get_template_part('templates/components/generic-row'); ?>
  <?php get_template_part('templates/components/generic-four-cards-section'); ?>
