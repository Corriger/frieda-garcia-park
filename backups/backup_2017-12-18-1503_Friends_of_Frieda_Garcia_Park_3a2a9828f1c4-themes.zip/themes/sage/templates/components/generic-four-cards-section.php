<section class="generic-four-cards-section">
  <?php get_template_part('templates/components/generic-card'); ?>
</section>
