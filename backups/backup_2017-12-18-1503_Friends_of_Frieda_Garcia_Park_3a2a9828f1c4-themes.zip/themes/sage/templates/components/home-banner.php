<section class="hero banner">
  <h3><?php echo get_field('home-banner-body');?></h3>
  <img src="<?php echo get_field('home-banner-image');?>" />
</section>
