<?php
/**
 * Template Name: Home Template
 */
?>
<?php get_template_part('templates/components/hero-banner'); ?>
<?php get_template_part('templates/components/generic-row'); ?>
