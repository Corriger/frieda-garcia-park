<header class="clearfix">
  <img src="<?php bloginfo('template_directory'); ?>/assets/images/logo.png" alt="ffgp-logo"/>
  <nav class="nav-mobile clearfix">
    <?php wp_nav_menu(); ?>
  </nav>
</header>
